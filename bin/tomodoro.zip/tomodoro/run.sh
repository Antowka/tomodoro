#!/usr/bin/env bash
java -Dfile.encoding=UTF-8 -jar tomodoro-1.0-all.jar -Xms=64m -Xmx=64m